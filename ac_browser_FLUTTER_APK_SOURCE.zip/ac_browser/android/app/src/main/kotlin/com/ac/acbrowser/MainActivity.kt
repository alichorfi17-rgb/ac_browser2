package com.ac.acbrowser

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
