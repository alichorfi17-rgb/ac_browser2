/// Global application constants for AC Browser
class AppConstants {
  AppConstants._();

  // App Info
  static const String appName = 'AC Browser';
  static const String appVersion = '1.0.0';
  static const String developer = 'AC';

  // Default URLs
  static const String homeUrl = 'about:blank';
  static const String defaultSearchEngine = 'google';

  // Search Engine URLs
  static const Map<String, SearchEngineConfig> searchEngines = {
    'google': SearchEngineConfig(
      name: 'Google',
      searchUrl: 'https://www.google.com/search?q=',
      homepageUrl: 'https://www.google.com',
      iconUrl: 'https://www.google.com/favicon.ico',
    ),
    'bing': SearchEngineConfig(
      name: 'Bing',
      searchUrl: 'https://www.bing.com/search?q=',
      homepageUrl: 'https://www.bing.com',
      iconUrl: 'https://www.bing.com/favicon.ico',
    ),
    'duckduckgo': SearchEngineConfig(
      name: 'DuckDuckGo',
      searchUrl: 'https://duckduckgo.com/?q=',
      homepageUrl: 'https://duckduckgo.com',
      iconUrl: 'https://duckduckgo.com/favicon.ico',
    ),
  };

  // Quick Access Sites
  static const List<QuickSiteConfig> quickAccessSites = [
    QuickSiteConfig(
      name: 'Google',
      url: 'https://www.google.com',
      iconPath: 'assets/icons/google.png',
    ),
    QuickSiteConfig(
      name: 'YouTube',
      url: 'https://www.youtube.com',
      iconPath: 'assets/icons/youtube.png',
    ),
    QuickSiteConfig(
      name: 'Facebook',
      url: 'https://www.facebook.com',
      iconPath: 'assets/icons/facebook.png',
    ),
    QuickSiteConfig(
      name: 'Wikipedia',
      url: 'https://www.wikipedia.org',
      iconPath: 'assets/icons/wikipedia.png',
    ),
    QuickSiteConfig(
      name: 'Gmail',
      url: 'https://mail.google.com',
      iconPath: 'assets/icons/gmail.png',
    ),
  ];

  // Ad Block Lists
  static const List<String> adBlockLists = [
    'https://easylist.to/easylist/easylist.txt',
    'https://easylist.to/easylist/easyprivacy.txt',
  ];

  // Database
  static const String dbName = 'ac_browser.db';
  static const int dbVersion = 1;

  // Max values
  static const int maxTabs = 100;
  static const int maxRecentHistory = 1000;
  static const int maxBookmarks = 10000;

  // Timeouts
  static const int connectionTimeout = 30000;
  static const int receiveTimeout = 30000;

  // Animation durations
  static const Duration shortAnimation = Duration(milliseconds: 150);
  static const Duration mediumAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);

  // Languages for translator
  static const Map<String, String> supportedLanguages = {
    'ar': 'Arabic',
    'en': 'English',
    'fr': 'French',
  };
}

class SearchEngineConfig {
  final String name;
  final String searchUrl;
  final String homepageUrl;
  final String iconUrl;

  const SearchEngineConfig({
    required this.name,
    required this.searchUrl,
    required this.homepageUrl,
    required this.iconUrl,
  });
}

class QuickSiteConfig {
  final String name;
  final String url;
  final String iconPath;

  const QuickSiteConfig({
    required this.name,
    required this.url,
    required this.iconPath,
  });
}
