import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Brand Colors
  static const Color primaryColor = Color(0xFF0A84FF);
  static const Color primaryDark = Color(0xFF0066CC);
  static const Color accentColor = Color(0xFF30D158);
  static const Color errorColor = Color(0xFFFF453A);
  static const Color warningColor = Color(0xFFFF9F0A);

  // Light Mode
  static const Color backgroundLight = Color(0xFFFFFFFF);
  static const Color surfaceLight = Color(0xFFF2F2F7);
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color textLight = Color(0xFF000000);
  static const Color textSecondaryLight = Color(0xFF6C6C70);
  static const Color dividerLight = Color(0xFFE5E5EA);
  static const Color addressBarLight = Color(0xFFF2F2F7);

  // Dark Mode
  static const Color backgroundDark = Color(0xFF121212);
  static const Color surfaceDark = Color(0xFF1C1C1E);
  static const Color cardDark = Color(0xFF2C2C2E);
  static const Color textDark = Color(0xFFFFFFFF);
  static const Color textSecondaryDark = Color(0xFF8E8E93);
  static const Color dividerDark = Color(0xFF38383A);
  static const Color addressBarDark = Color(0xFF2C2C2E);

  // Private Mode Colors
  static const Color privateBackground = Color(0xFF1A0A2E);
  static const Color privateSurface = Color(0xFF2D1B4E);
  static const Color privateAccent = Color(0xFF9B5DE5);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: Brightness.light,
        primary: primaryColor,
        secondary: accentColor,
        error: errorColor,
        surface: surfaceLight,
      ),
      scaffoldBackgroundColor: backgroundLight,
      textTheme: _buildTextTheme(textLight),
      appBarTheme: const AppBarTheme(
        backgroundColor: backgroundLight,
        foregroundColor: textLight,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardTheme(
        color: cardLight,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: addressBarLight,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      iconTheme: const IconThemeData(color: textLight),
      dividerTheme: const DividerThemeData(
        color: dividerLight,
        thickness: 0.5,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: backgroundLight,
        selectedItemColor: primaryColor,
        unselectedItemColor: textSecondaryLight,
        elevation: 0,
      ),
      extensions: const [
        ACBrowserThemeExtension(
          addressBarColor: addressBarLight,
          textSecondary: textSecondaryLight,
          dividerColor: dividerLight,
          privateBackground: privateBackground,
          privateSurface: privateSurface,
          privateAccent: privateAccent,
        ),
      ],
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        brightness: Brightness.dark,
        primary: primaryColor,
        secondary: accentColor,
        error: errorColor,
        surface: surfaceDark,
      ),
      scaffoldBackgroundColor: backgroundDark,
      textTheme: _buildTextTheme(textDark),
      appBarTheme: const AppBarTheme(
        backgroundColor: backgroundDark,
        foregroundColor: textDark,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardTheme(
        color: cardDark,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: addressBarDark,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      iconTheme: const IconThemeData(color: textDark),
      dividerTheme: const DividerThemeData(
        color: dividerDark,
        thickness: 0.5,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: backgroundDark,
        selectedItemColor: primaryColor,
        unselectedItemColor: textSecondaryDark,
        elevation: 0,
      ),
      extensions: const [
        ACBrowserThemeExtension(
          addressBarColor: addressBarDark,
          textSecondary: textSecondaryDark,
          dividerColor: dividerDark,
          privateBackground: privateBackground,
          privateSurface: privateSurface,
          privateAccent: privateAccent,
        ),
      ],
    );
  }

  static TextTheme _buildTextTheme(Color baseColor) {
    return GoogleFonts.interTextTheme(
      TextTheme(
        displayLarge: TextStyle(color: baseColor, fontWeight: FontWeight.bold),
        displayMedium: TextStyle(color: baseColor, fontWeight: FontWeight.bold),
        displaySmall: TextStyle(color: baseColor, fontWeight: FontWeight.w600),
        headlineLarge: TextStyle(color: baseColor, fontWeight: FontWeight.w600),
        headlineMedium: TextStyle(color: baseColor, fontWeight: FontWeight.w600),
        headlineSmall: TextStyle(color: baseColor, fontWeight: FontWeight.w600),
        titleLarge: TextStyle(color: baseColor, fontWeight: FontWeight.w600),
        titleMedium: TextStyle(color: baseColor, fontWeight: FontWeight.w500),
        titleSmall: TextStyle(color: baseColor, fontWeight: FontWeight.w500),
        bodyLarge: TextStyle(color: baseColor),
        bodyMedium: TextStyle(color: baseColor),
        bodySmall: TextStyle(color: baseColor.withOpacity(0.7)),
        labelLarge: TextStyle(color: baseColor, fontWeight: FontWeight.w500),
        labelMedium: TextStyle(color: baseColor.withOpacity(0.7)),
        labelSmall: TextStyle(color: baseColor.withOpacity(0.5)),
      ),
    );
  }
}

/// Custom theme extension for AC Browser specific colors
@immutable
class ACBrowserThemeExtension extends ThemeExtension<ACBrowserThemeExtension> {
  const ACBrowserThemeExtension({
    required this.addressBarColor,
    required this.textSecondary,
    required this.dividerColor,
    required this.privateBackground,
    required this.privateSurface,
    required this.privateAccent,
  });

  final Color addressBarColor;
  final Color textSecondary;
  final Color dividerColor;
  final Color privateBackground;
  final Color privateSurface;
  final Color privateAccent;

  @override
  ACBrowserThemeExtension copyWith({
    Color? addressBarColor,
    Color? textSecondary,
    Color? dividerColor,
    Color? privateBackground,
    Color? privateSurface,
    Color? privateAccent,
  }) {
    return ACBrowserThemeExtension(
      addressBarColor: addressBarColor ?? this.addressBarColor,
      textSecondary: textSecondary ?? this.textSecondary,
      dividerColor: dividerColor ?? this.dividerColor,
      privateBackground: privateBackground ?? this.privateBackground,
      privateSurface: privateSurface ?? this.privateSurface,
      privateAccent: privateAccent ?? this.privateAccent,
    );
  }

  @override
  ACBrowserThemeExtension lerp(
      ACBrowserThemeExtension? other, double t) {
    if (other is! ACBrowserThemeExtension) return this;
    return ACBrowserThemeExtension(
      addressBarColor: Color.lerp(addressBarColor, other.addressBarColor, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      dividerColor: Color.lerp(dividerColor, other.dividerColor, t)!,
      privateBackground:
          Color.lerp(privateBackground, other.privateBackground, t)!,
      privateSurface: Color.lerp(privateSurface, other.privateSurface, t)!,
      privateAccent: Color.lerp(privateAccent, other.privateAccent, t)!,
    );
  }
}
