/// URL utility helpers for AC Browser
class UrlUtils {
  UrlUtils._();

  /// Extract display hostname from full URL (removes www.)
  static String displayHost(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.host.replaceFirst(RegExp(r'^www\.'), '');
    } catch (_) {
      return url;
    }
  }

  /// Build favicon URL from domain
  static String faviconUrl(String pageUrl) {
    try {
      final uri = Uri.parse(pageUrl);
      return '${uri.scheme}://${uri.host}/favicon.ico';
    } catch (_) {
      return '';
    }
  }

  /// Check if string looks like a URL vs search query
  static bool looksLikeUrl(String input) {
    if (input.startsWith('http://') || input.startsWith('https://')) {
      return true;
    }
    if (!input.contains(' ') && input.contains('.')) {
      final parts = input.split('.');
      if (parts.length >= 2 && parts.last.length >= 2) return true;
    }
    return false;
  }

  /// Shorten URL for display
  static String shortUrl(String url, {int maxLength = 50}) {
    if (url.length <= maxLength) return url;
    return '${url.substring(0, maxLength)}...';
  }

  /// Returns true if the URL is a special browser page
  static bool isSpecialPage(String url) {
    return url == 'about:blank' ||
        url.startsWith('chrome://') ||
        url.startsWith('about:');
  }
}
