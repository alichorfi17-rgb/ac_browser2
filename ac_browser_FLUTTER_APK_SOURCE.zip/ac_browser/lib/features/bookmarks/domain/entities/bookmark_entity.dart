/// Domain entity for a bookmark
class BookmarkEntity {
  final int? id;
  final String title;
  final String url;
  final String? favicon;
  final DateTime createdAt;

  const BookmarkEntity({
    this.id,
    required this.title,
    required this.url,
    this.favicon,
    required this.createdAt,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BookmarkEntity &&
          runtimeType == other.runtimeType &&
          url == other.url;

  @override
  int get hashCode => url.hashCode;

  @override
  String toString() =>
      'BookmarkEntity(id: $id, title: $title, url: $url)';
}

/// Abstract repository contract
abstract class BookmarkRepository {
  Future<List<BookmarkEntity>> getAll();
  Future<List<BookmarkEntity>> search(String query);
  Future<BookmarkEntity> add(String title, String url, {String? favicon});
  Future<void> remove(int id);
  Future<void> update(int id, String title, String url, {String? favicon});
  Future<bool> exists(String url);
}
