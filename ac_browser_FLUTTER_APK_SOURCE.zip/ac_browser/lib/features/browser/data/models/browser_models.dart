/// Data model for a browser session snapshot (used for serialization)
class BrowserSessionModel {
  final List<TabModel> tabs;
  final int activeTabIndex;
  final bool isPrivateMode;

  const BrowserSessionModel({
    required this.tabs,
    required this.activeTabIndex,
    required this.isPrivateMode,
  });

  factory BrowserSessionModel.fromJson(Map<String, dynamic> json) {
    return BrowserSessionModel(
      tabs: (json['tabs'] as List<dynamic>? ?? [])
          .map((t) => TabModel.fromJson(t as Map<String, dynamic>))
          .toList(),
      activeTabIndex: json['activeTabIndex'] as int? ?? 0,
      isPrivateMode: json['isPrivateMode'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'tabs': tabs.map((t) => t.toJson()).toList(),
        'activeTabIndex': activeTabIndex,
        'isPrivateMode': isPrivateMode,
      };
}

/// Data model for a single tab
class TabModel {
  final String id;
  final String title;
  final String url;
  final bool isPrivate;
  final DateTime lastVisited;

  const TabModel({
    required this.id,
    required this.title,
    required this.url,
    required this.isPrivate,
    required this.lastVisited,
  });

  factory TabModel.fromJson(Map<String, dynamic> json) {
    return TabModel(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'New Tab',
      url: json['url'] as String? ?? 'about:blank',
      isPrivate: json['isPrivate'] as bool? ?? false,
      lastVisited: DateTime.tryParse(json['lastVisited'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'url': url,
        'isPrivate': isPrivate,
        'lastVisited': lastVisited.toIso8601String(),
      };
}

/// Data model for a bookmark (data layer)
class BookmarkModel {
  final int? id;
  final String title;
  final String url;
  final String? favicon;
  final DateTime createdAt;

  const BookmarkModel({
    this.id,
    required this.title,
    required this.url,
    this.favicon,
    required this.createdAt,
  });

  factory BookmarkModel.fromMap(Map<String, dynamic> map) => BookmarkModel(
        id: map['id'] as int?,
        title: map['title'] as String,
        url: map['url'] as String,
        favicon: map['favicon'] as String?,
        createdAt:
            DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'title': title,
        'url': url,
        if (favicon != null) 'favicon': favicon,
        'created_at': createdAt.toIso8601String(),
      };
}

/// Data model for a history item
class HistoryModel {
  final int? id;
  final String? title;
  final String url;
  final DateTime visitTime;

  const HistoryModel({
    this.id,
    this.title,
    required this.url,
    required this.visitTime,
  });

  factory HistoryModel.fromMap(Map<String, dynamic> map) => HistoryModel(
        id: map['id'] as int?,
        title: map['title'] as String?,
        url: map['url'] as String,
        visitTime:
            DateTime.tryParse(map['visit_time'] as String? ?? '') ?? DateTime.now(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        if (title != null) 'title': title,
        'url': url,
        'visit_time': visitTime.toIso8601String(),
      };
}

/// Data model for a download
class DownloadModel {
  final int? id;
  final String fileName;
  final String filePath;
  final String url;
  final int size;
  final String? mimeType;
  final String status;
  final double progress;
  final DateTime downloadDate;

  const DownloadModel({
    this.id,
    required this.fileName,
    required this.filePath,
    required this.url,
    this.size = 0,
    this.mimeType,
    this.status = 'pending',
    this.progress = 0.0,
    required this.downloadDate,
  });

  factory DownloadModel.fromMap(Map<String, dynamic> map) => DownloadModel(
        id: map['id'] as int?,
        fileName: map['file_name'] as String,
        filePath: map['file_path'] as String,
        url: map['url'] as String,
        size: (map['size'] as int?) ?? 0,
        mimeType: map['mime_type'] as String?,
        status: map['status'] as String? ?? 'pending',
        progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
        downloadDate:
            DateTime.tryParse(map['download_date'] as String? ?? '') ?? DateTime.now(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'file_name': fileName,
        'file_path': filePath,
        'url': url,
        'size': size,
        if (mimeType != null) 'mime_type': mimeType,
        'status': status,
        'progress': progress,
        'download_date': downloadDate.toIso8601String(),
      };
}
