import 'package:flutter_inappwebview/flutter_inappwebview.dart';

/// Represents a single browser tab
class BrowserTab {
  final String id;
  String title;
  String url;
  String? favicon;
  bool isLoading;
  double loadingProgress;
  bool isPrivate;
  bool canGoBack;
  bool canGoForward;
  int blockedAdsCount;
  bool isSecure;
  InAppWebViewController? controller;
  String? thumbnail;
  DateTime createdAt;
  DateTime lastVisited;

  BrowserTab({
    required this.id,
    this.title = 'New Tab',
    this.url = 'about:blank',
    this.favicon,
    this.isLoading = false,
    this.loadingProgress = 0.0,
    this.isPrivate = false,
    this.canGoBack = false,
    this.canGoForward = false,
    this.blockedAdsCount = 0,
    this.isSecure = false,
    this.controller,
    this.thumbnail,
    DateTime? createdAt,
    DateTime? lastVisited,
  })  : createdAt = createdAt ?? DateTime.now(),
        lastVisited = lastVisited ?? DateTime.now();

  BrowserTab copyWith({
    String? id,
    String? title,
    String? url,
    String? favicon,
    bool? isLoading,
    double? loadingProgress,
    bool? isPrivate,
    bool? canGoBack,
    bool? canGoForward,
    int? blockedAdsCount,
    bool? isSecure,
    InAppWebViewController? controller,
    String? thumbnail,
    DateTime? createdAt,
    DateTime? lastVisited,
  }) {
    return BrowserTab(
      id: id ?? this.id,
      title: title ?? this.title,
      url: url ?? this.url,
      favicon: favicon ?? this.favicon,
      isLoading: isLoading ?? this.isLoading,
      loadingProgress: loadingProgress ?? this.loadingProgress,
      isPrivate: isPrivate ?? this.isPrivate,
      canGoBack: canGoBack ?? this.canGoBack,
      canGoForward: canGoForward ?? this.canGoForward,
      blockedAdsCount: blockedAdsCount ?? this.blockedAdsCount,
      isSecure: isSecure ?? this.isSecure,
      controller: controller ?? this.controller,
      thumbnail: thumbnail ?? this.thumbnail,
      createdAt: createdAt ?? this.createdAt,
      lastVisited: lastVisited ?? this.lastVisited,
    );
  }

  bool get isHomePage => url == 'about:blank' || url.isEmpty;
  bool get hasValidUrl => url.isNotEmpty && url != 'about:blank';
}
