import '../../../../core/di/injection.dart';
import '../../../../services/history_service.dart';
import '../../../../services/bookmark_service.dart';
import '../../../../services/security_service.dart';
import '../../../../services/ad_block_service.dart';

/// Use case: process URL or search input into a valid URL
class ProcessUrlUseCase {
  final SecurityService _security = getIt<SecurityService>();

  String call(String input, String searchEngine) {
    return _security.processInput(input, searchEngine);
  }
}

/// Use case: record a page visit in history
class RecordHistoryUseCase {
  final HistoryService _history = getIt<HistoryService>();

  Future<void> call({
    required String url,
    String? title,
    bool isPrivate = false,
  }) async {
    if (isPrivate) return;
    await _history.addEntry(url: url, title: title);
  }
}

/// Use case: toggle bookmark for current page
class ToggleBookmarkUseCase {
  final BookmarkService _bookmarks = getIt<BookmarkService>();

  Future<bool> call({required String url, required String title}) async {
    final isBookmarked = await _bookmarks.isBookmarked(url);
    if (isBookmarked) {
      final all = await _bookmarks.getAllBookmarks();
      final existing = all.firstWhere((b) => b.url == url,
          orElse: () => Bookmark(title: title, url: url));
      if (existing.id != null) {
        await _bookmarks.removeBookmark(existing.id!);
      }
      return false;
    } else {
      await _bookmarks.addBookmark(title: title, url: url);
      return true;
    }
  }

  Future<bool> isBookmarked(String url) => _bookmarks.isBookmarked(url);
}

/// Use case: check if a URL should be blocked
class CheckAdBlockUseCase {
  final AdBlockService _adBlock = getIt<AdBlockService>();

  bool call(String url) => _adBlock.shouldBlock(url);
}
