import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class ReadingModeScreen extends StatefulWidget {
  final String url;
  final String title;

  const ReadingModeScreen({
    super.key,
    required this.url,
    required this.title,
  });

  @override
  State<ReadingModeScreen> createState() => _ReadingModeScreenState();
}

class _ReadingModeScreenState extends State<ReadingModeScreen> {
  InAppWebViewController? _controller;
  double _fontSize = 18.0;
  String _theme = 'light';
  bool _showControls = false;
  bool _isLoading = true;

  // JavaScript to extract and style readable content
  static const String _readerScript = '''
    (function() {
      // Remove ads, nav, sidebars, footers
      const removeSelectors = [
        'nav', 'header', 'footer', 'aside', '.ad', '.ads', '.advertisement',
        '.sidebar', '.widget', '.popup', '.modal', '.cookie-banner',
        '[class*="ad-"]', '[class*="-ad"]', '[id*="ad-"]', '[id*="-ad"]',
        '.social-share', '.newsletter', '.related-posts', '.comments',
        '#comments', '.comment-section', '.share-buttons',
      ];
      removeSelectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => el.remove());
      });
      
      // Find main content
      const selectors = ['article', 'main', '.post-content', '.article-body',
        '.entry-content', '.content', '#content', '.story-body'];
      let content = null;
      for (const sel of selectors) {
        content = document.querySelector(sel);
        if (content) break;
      }
      if (!content) content = document.body;
      
      // Apply reader styles
      document.body.innerHTML = '<div id="reader-content">' + content.innerHTML + '</div>';
      document.getElementById('reader-content').style.cssText = 
        'max-width: 680px; margin: 0 auto; padding: 20px 16px; font-family: Georgia, serif; line-height: 1.8; font-size: FONT_SIZEpx; color: TEXT_COLOR; background: BG_COLOR;';
      document.body.style.background = 'BG_COLOR';
      
      // Remove inline styles from images to make them responsive
      document.querySelectorAll('img').forEach(img => {
        img.style.maxWidth = '100%';
        img.style.height = 'auto';
      });
    })();
  ''';

  final Map<String, Map<String, String>> _themes = {
    'light': {'bg': '#FFFFFF', 'text': '#1a1a1a'},
    'sepia': {'bg': '#F8F0E3', 'text': '#3d2b1f'},
    'dark': {'bg': '#1a1a1a', 'text': '#e8e8e8'},
  };

  String _buildScript() {
    final t = _themes[_theme]!;
    return _readerScript
        .replaceAll('FONT_SIZE', _fontSize.toString())
        .replaceAll('TEXT_COLOR', t['text']!)
        .replaceAll('BG_COLOR', t['bg']!);
  }

  Future<void> _applyReaderMode() async {
    await _controller?.evaluateJavascript(source: _buildScript());
  }

  @override
  Widget build(BuildContext context) {
    final isDark = _theme == 'dark';
    final bgColor = Color(
        int.parse(_themes[_theme]!['bg']!.replaceFirst('#', '0xFF')));

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        foregroundColor: isDark ? Colors.white : Colors.black87,
        elevation: 0,
        title: Text(
          widget.title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: Icon(
              _showControls ? Icons.tune_rounded : Icons.tune_outlined,
            ),
            onPressed: () => setState(() => _showControls = !_showControls),
          ),
        ],
      ),
      body: Column(
        children: [
          // Reader controls panel
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            child: _showControls
                ? _ReaderControls(
                    fontSize: _fontSize,
                    theme: _theme,
                    isDark: isDark,
                    onFontSizeChanged: (v) {
                      setState(() => _fontSize = v);
                      _applyReaderMode();
                    },
                    onThemeChanged: (v) {
                      setState(() => _theme = v);
                      _applyReaderMode();
                    },
                  )
                : const SizedBox.shrink(),
          ),

          // Loading indicator
          if (_isLoading)
            LinearProgressIndicator(
              minHeight: 2,
              backgroundColor: Colors.transparent,
              color: const Color(0xFF0A84FF),
            ),

          // WebView
          Expanded(
            child: InAppWebView(
              initialUrlRequest: URLRequest(url: WebUri(widget.url)),
              initialSettings: InAppWebViewSettings(
                javaScriptEnabled: true,
                useOnLoadResource: false,
                disableHorizontalScroll: false,
              ),
              onWebViewCreated: (c) => _controller = c,
              onLoadStop: (c, url) async {
                setState(() => _isLoading = false);
                await Future.delayed(const Duration(milliseconds: 300));
                await _applyReaderMode();
              },
              onProgressChanged: (c, p) {
                if (p < 100) setState(() => _isLoading = true);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ReaderControls extends StatelessWidget {
  final double fontSize;
  final String theme;
  final bool isDark;
  final ValueChanged<double> onFontSizeChanged;
  final ValueChanged<String> onThemeChanged;

  const _ReaderControls({
    required this.fontSize,
    required this.theme,
    required this.isDark,
    required this.onFontSizeChanged,
    required this.onThemeChanged,
  });

  @override
  Widget build(BuildContext context) {
    final panelBg = isDark ? const Color(0xFF2a2a2a) : Colors.grey.shade50;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Container(
      padding: const EdgeInsets.all(16),
      color: panelBg,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Font size
          Row(
            children: [
              Icon(Icons.text_fields_rounded, color: textColor, size: 18),
              const SizedBox(width: 8),
              Text('Font Size',
                  style: TextStyle(color: textColor, fontSize: 14)),
              const Spacer(),
              IconButton(
                icon: Icon(Icons.remove_rounded, color: textColor),
                onPressed: fontSize > 12
                    ? () => onFontSizeChanged(fontSize - 2)
                    : null,
              ),
              Text(
                '${fontSize.toInt()}',
                style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.w600,
                    fontSize: 16),
              ),
              IconButton(
                icon: Icon(Icons.add_rounded, color: textColor),
                onPressed: fontSize < 28
                    ? () => onFontSizeChanged(fontSize + 2)
                    : null,
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Theme selection
          Row(
            children: [
              Icon(Icons.palette_outlined, color: textColor, size: 18),
              const SizedBox(width: 8),
              Text('Theme',
                  style: TextStyle(color: textColor, fontSize: 14)),
              const Spacer(),
              _ThemeChip(
                  label: 'Light',
                  value: 'light',
                  current: theme,
                  bg: Colors.white,
                  text: Colors.black87,
                  onTap: onThemeChanged),
              const SizedBox(width: 8),
              _ThemeChip(
                  label: 'Sepia',
                  value: 'sepia',
                  current: theme,
                  bg: const Color(0xFFF8F0E3),
                  text: const Color(0xFF3d2b1f),
                  onTap: onThemeChanged),
              const SizedBox(width: 8),
              _ThemeChip(
                  label: 'Dark',
                  value: 'dark',
                  current: theme,
                  bg: const Color(0xFF1a1a1a),
                  text: Colors.white,
                  onTap: onThemeChanged),
            ],
          ),
        ],
      ),
    );
  }
}

class _ThemeChip extends StatelessWidget {
  final String label;
  final String value;
  final String current;
  final Color bg;
  final Color text;
  final ValueChanged<String> onTap;

  const _ThemeChip({
    required this.label,
    required this.value,
    required this.current,
    required this.bg,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = value == current;
    return GestureDetector(
      onTap: () => onTap(value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF0A84FF)
                : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Text(label,
            style: TextStyle(
                color: text,
                fontSize: 12,
                fontWeight: isSelected
                    ? FontWeight.w600
                    : FontWeight.w400)),
      ),
    );
  }
}
