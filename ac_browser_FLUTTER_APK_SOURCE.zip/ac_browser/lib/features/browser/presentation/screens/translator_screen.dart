import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:dio/dio.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/di/injection.dart';

class TranslatorScreen extends StatefulWidget {
  final String url;
  final String title;

  const TranslatorScreen({
    super.key,
    required this.url,
    required this.title,
  });

  @override
  State<TranslatorScreen> createState() => _TranslatorScreenState();
}

class _TranslatorScreenState extends State<TranslatorScreen> {
  String _targetLang = 'ar';
  bool _isTranslating = false;
  InAppWebViewController? _controller;

  // Google Translate works via URL redirect — simplest approach
  String get _translateUrl =>
      'https://translate.google.com/translate?sl=auto&tl=$_targetLang&u=${Uri.encodeComponent(widget.url)}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Translate Page',
            style: TextStyle(fontWeight: FontWeight.w600)),
        actions: [
          // Language selector
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: DropdownButton<String>(
              value: _targetLang,
              underline: const SizedBox(),
              borderRadius: BorderRadius.circular(12),
              items: AppConstants.supportedLanguages.entries.map((e) {
                return DropdownMenuItem(
                  value: e.key,
                  child: Text(e.value,
                      style: const TextStyle(fontSize: 14)),
                );
              }).toList(),
              onChanged: (v) {
                if (v != null) {
                  setState(() => _targetLang = v);
                  _controller?.loadUrl(
                      urlRequest: URLRequest(
                          url: WebUri(_translateUrl)));
                }
              },
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          InAppWebView(
            initialUrlRequest:
                URLRequest(url: WebUri(_translateUrl)),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useOnLoadResource: false,
            ),
            onWebViewCreated: (c) => _controller = c,
            onLoadStart: (_, __) =>
                setState(() => _isTranslating = true),
            onLoadStop: (_, __) =>
                setState(() => _isTranslating = false),
          ),
          if (_isTranslating)
            const LinearProgressIndicator(
              minHeight: 2,
              backgroundColor: Colors.transparent,
              color: Color(0xFF0A84FF),
            ),
        ],
      ),
    );
  }
}
