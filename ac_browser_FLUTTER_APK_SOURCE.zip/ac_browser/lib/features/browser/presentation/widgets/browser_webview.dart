import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/ad_block_service.dart';
import '../../../../services/history_service.dart';
import '../../../../services/security_service.dart';
import '../../domain/entities/browser_tab.dart';
import '../providers/browser_provider.dart';
import '../../../../features/settings/presentation/providers/settings_provider.dart';

class BrowserWebView extends ConsumerStatefulWidget {
  final BrowserTab tab;

  const BrowserWebView({super.key, required this.tab});

  @override
  ConsumerState<BrowserWebView> createState() => _BrowserWebViewState();
}

class _BrowserWebViewState extends ConsumerState<BrowserWebView> {
  InAppWebViewController? _controller;
  final _adBlockService = getIt<AdBlockService>();
  final _historyService = getIt<HistoryService>();
  final _securityService = getIt<SecurityService>();

  InAppWebViewSettings get _webViewSettings {
    final settings = ref.read(settingsProvider);
    return InAppWebViewSettings(
      javaScriptEnabled: settings.javascriptEnabled,
      javaScriptCanOpenWindowsAutomatically: false,
      useOnDownloadStart: true,
      useOnLoadResource: true,
      useShouldOverrideUrlLoading: true,
      mediaPlaybackRequiresUserGesture: false,
      allowsInlineMediaPlayback: true,
      isFocusable: true,
      useHybridComposition: true,
      supportMultipleWindows: false,
      transparentBackground: true,
      disableDefaultErrorPage: false,
      safeBrowsingEnabled: settings.safeBrowsing,
      thirdPartyCookiesEnabled: settings.cookiesEnabled,
      domStorageEnabled: !widget.tab.isPrivate,
      databaseEnabled: !widget.tab.isPrivate,
      cacheEnabled: !widget.tab.isPrivate,
      clearCache: widget.tab.isPrivate,
      incognito: widget.tab.isPrivate,
      userAgent:
          'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.tab.isHomePage) return const SizedBox.shrink();

    return SafeArea(
      bottom: false,
      child: InAppWebView(
        initialUrlRequest: URLRequest(
          url: WebUri(widget.tab.url),
        ),
        initialSettings: _webViewSettings,
        onWebViewCreated: (controller) {
          _controller = controller;
          ref.read(browserProvider.notifier).updateTabById(
                widget.tab.id,
                (tab) {
                  tab.controller = controller;
                  return tab;
                },
              );
        },
        onLoadStart: (controller, url) {
          final urlStr = url?.toString() ?? '';
          ref.read(browserProvider.notifier).updateTabById(
                widget.tab.id,
                (tab) {
                  tab.isLoading = true;
                  tab.loadingProgress = 0.0;
                  tab.url = urlStr;
                  tab.isSecure = _securityService.isSecureUrl(urlStr);
                  return tab;
                },
              );
        },
        onLoadStop: (controller, url) async {
          final urlStr = url?.toString() ?? '';
          final title = await controller.getTitle() ?? urlStr;
          final canGoBack = await controller.canGoBack();
          final canGoForward = await controller.canGoForward();

          ref.read(browserProvider.notifier).updateTabById(
                widget.tab.id,
                (tab) {
                  tab.isLoading = false;
                  tab.loadingProgress = 1.0;
                  tab.url = urlStr;
                  tab.title = title;
                  tab.canGoBack = canGoBack;
                  tab.canGoForward = canGoForward;
                  tab.isSecure = _securityService.isSecureUrl(urlStr);
                  return tab;
                },
              );

          // Save to history (skip private mode)
          if (!widget.tab.isPrivate) {
            await _historyService.addEntry(url: urlStr, title: title);
          }
        },
        onProgressChanged: (controller, progress) {
          ref.read(browserProvider.notifier).updateTabById(
                widget.tab.id,
                (tab) {
                  tab.loadingProgress = progress / 100.0;
                  return tab;
                },
              );
        },
        onTitleChanged: (controller, title) {
          if (title != null) {
            ref.read(browserProvider.notifier).updateTabById(
                  widget.tab.id,
                  (tab) {
                    tab.title = title;
                    return tab;
                  },
                );
          }
        },
        onReceivedIcon: (controller, icon) async {
          // Favicon received - convert to base64 if needed
        },
        shouldOverrideUrlLoading: (controller, navigationAction) async {
          final url = navigationAction.request.url?.toString() ?? '';
          final settings = ref.read(settingsProvider);

          // Ad blocking
          if (settings.adBlockEnabled && _adBlockService.shouldBlock(url)) {
            ref.read(browserProvider.notifier).incrementBlockedAds(widget.tab.id);
            return NavigationActionPolicy.CANCEL;
          }

          return NavigationActionPolicy.ALLOW;
        },
        onDownloadStartRequest: (controller, downloadStartRequest) {
          _handleDownload(downloadStartRequest.url.toString(),
              downloadStartRequest.suggestedFilename ?? 'download');
        },
        onConsoleMessage: (controller, consoleMessage) {
          // Optionally log console messages in debug mode
        },
        onCreateWindow: (controller, createWindowAction) async {
          // Open new tab for popup requests
          final url = createWindowAction.request.url?.toString() ?? 'about:blank';
          ref.read(browserProvider.notifier).addNewTab(url: url);
          return true;
        },
        onReceivedError: (controller, request, error) {
          // Handle load errors
        },
      ),
    );
  }

  void _handleDownload(String url, String filename) {
    // Show download dialog
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _DownloadSheet(url: url, filename: filename),
    );
  }
}

class _DownloadSheet extends StatelessWidget {
  final String url;
  final String filename;

  const _DownloadSheet({required this.url, required this.filename});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.download_rounded, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Download File',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                    ),
                    Text(
                      filename,
                      style: const TextStyle(fontSize: 13, color: Colors.grey),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    Navigator.pop(context);
                    // Trigger actual download
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Downloading $filename...'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                  child: const Text('Download'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
