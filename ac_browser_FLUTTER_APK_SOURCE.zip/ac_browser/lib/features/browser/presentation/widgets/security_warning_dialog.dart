import 'package:flutter/material.dart';

class SecurityWarningDialog extends StatelessWidget {
  final String url;
  final VoidCallback onProceed;
  final VoidCallback onCancel;

  const SecurityWarningDialog({
    super.key,
    required this.url,
    required this.onProceed,
    required this.onCancel,
  });

  static Future<bool?> show(BuildContext context, String url) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => SecurityWarningDialog(
        url: url,
        onProceed: () => Navigator.pop(ctx, true),
        onCancel: () => Navigator.pop(ctx, false),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFFF453A).withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.warning_amber_rounded,
              color: Color(0xFFFF453A),
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'Security Warning',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'This site may be harmful. It has been identified as a potential phishing or malware source.',
            style: TextStyle(fontSize: 14),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              url,
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontFamily: 'monospace',
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: onCancel,
          child: const Text('Go Back'),
        ),
        TextButton(
          onPressed: onProceed,
          style: TextButton.styleFrom(
            foregroundColor: const Color(0xFFFF453A),
          ),
          child: const Text('Proceed Anyway'),
        ),
      ],
    );
  }
}
