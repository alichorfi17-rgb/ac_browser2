import '../../domain/entities/download_entity.dart';
import '../../domain/repositories/download_repository.dart';
import '../datasources/downloads_datasource.dart';

class DownloadRepositoryImpl implements DownloadRepository {
  final DownloadsDataSource _dataSource;

  DownloadRepositoryImpl(this._dataSource);

  @override
  Future<List<DownloadEntity>> getAll() => _dataSource.getAll();

  @override
  Future<int> startDownload({
    required String url,
    required String fileName,
    required String filePath,
    String? mimeType,
  }) =>
      _dataSource.insert(
        fileName: fileName,
        filePath: filePath,
        url: url,
        mimeType: mimeType,
      );

  @override
  Future<void> updateProgress(int id, double progress) =>
      _dataSource.updateProgress(id, progress);

  @override
  Future<void> markCompleted(int id, int size) =>
      _dataSource.markCompleted(id, size);

  @override
  Future<void> markFailed(int id) => _dataSource.markFailed(id);

  @override
  Future<void> delete(int id) => _dataSource.delete(id);
}
