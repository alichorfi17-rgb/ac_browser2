import '../entities/download_entity.dart';

abstract class DownloadRepository {
  Future<List<DownloadEntity>> getAll();
  Future<int> startDownload({
    required String url,
    required String fileName,
    required String filePath,
    String? mimeType,
  });
  Future<void> updateProgress(int id, double progress);
  Future<void> markCompleted(int id, int size);
  Future<void> markFailed(int id);
  Future<void> delete(int id);
}
