import '../entities/download_entity.dart';
import '../repositories/download_repository.dart';

class GetAllDownloadsUseCase {
  final DownloadRepository _repo;
  GetAllDownloadsUseCase(this._repo);
  Future<List<DownloadEntity>> call() => _repo.getAll();
}

class StartDownloadUseCase {
  final DownloadRepository _repo;
  StartDownloadUseCase(this._repo);
  Future<int> call({
    required String url,
    required String fileName,
    required String filePath,
    String? mimeType,
  }) =>
      _repo.startDownload(
        url: url,
        fileName: fileName,
        filePath: filePath,
        mimeType: mimeType,
      );
}

class DeleteDownloadUseCase {
  final DownloadRepository _repo;
  DeleteDownloadUseCase(this._repo);
  Future<void> call(int id) => _repo.delete(id);
}

class UpdateDownloadProgressUseCase {
  final DownloadRepository _repo;
  UpdateDownloadProgressUseCase(this._repo);
  Future<void> call(int id, double progress) =>
      _repo.updateProgress(id, progress);
}
