import '../../../../database/database_helper.dart';
import '../../domain/entities/history_entity.dart';

class HistoryDataSource {
  final DatabaseHelper _db;

  HistoryDataSource(this._db);

  Future<List<HistoryEntity>> getRecent({int limit = 100}) async {
    final maps = await _db.getHistory(limit: limit);
    return maps.map(_fromMap).toList();
  }

  Future<List<HistoryEntity>> search(String query) async {
    final maps = await _db.searchHistory(query);
    return maps.map(_fromMap).toList();
  }

  Future<int> insert(String url, {String? title}) async {
    return await _db.insertHistory({
      'url': url,
      if (title != null) 'title': title,
      'visit_time': DateTime.now().toIso8601String(),
    });
  }

  Future<void> delete(int id) => _db.deleteHistoryItem(id);

  Future<void> clearAll() => _db.clearAllHistory();

  HistoryEntity _fromMap(Map<String, dynamic> m) => HistoryEntity(
        id: m['id'] as int?,
        title: m['title'] as String?,
        url: m['url'] as String,
        visitTime:
            DateTime.tryParse(m['visit_time'] as String? ?? '') ??
                DateTime.now(),
      );
}
