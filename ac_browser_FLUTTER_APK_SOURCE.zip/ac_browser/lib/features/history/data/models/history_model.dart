import '../../domain/entities/history_entity.dart';

/// Data model for history item stored in SQLite
class HistoryDataModel {
  final int? id;
  final String? title;
  final String url;
  final String visitTime;

  const HistoryDataModel({
    this.id,
    this.title,
    required this.url,
    required this.visitTime,
  });

  factory HistoryDataModel.fromMap(Map<String, dynamic> map) =>
      HistoryDataModel(
        id: map['id'] as int?,
        title: map['title'] as String?,
        url: map['url'] as String,
        visitTime: map['visit_time'] as String? ??
            DateTime.now().toIso8601String(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        if (title != null) 'title': title,
        'url': url,
        'visit_time': visitTime,
      };

  HistoryEntity toEntity() => HistoryEntity(
        id: id,
        title: title,
        url: url,
        visitTime: DateTime.tryParse(visitTime) ?? DateTime.now(),
      );

  factory HistoryDataModel.fromEntity(HistoryEntity entity) =>
      HistoryDataModel(
        id: entity.id,
        title: entity.title,
        url: entity.url,
        visitTime: entity.visitTime.toIso8601String(),
      );
}
