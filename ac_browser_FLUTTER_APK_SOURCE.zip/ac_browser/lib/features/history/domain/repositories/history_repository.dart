import '../entities/history_entity.dart';

abstract class HistoryRepository {
  Future<List<HistoryEntity>> getRecent({int limit = 100});
  Future<List<HistoryEntity>> search(String query);
  Future<void> add(String url, {String? title, bool isPrivate = false});
  Future<void> delete(int id);
  Future<void> clearAll();
}
