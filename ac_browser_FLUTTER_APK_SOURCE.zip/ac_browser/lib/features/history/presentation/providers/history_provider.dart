import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/history_service.dart';

class HistoryState {
  final List<HistoryItem> items;
  final bool isLoading;

  const HistoryState({this.items = const [], this.isLoading = false});

  HistoryState copyWith({List<HistoryItem>? items, bool? isLoading}) =>
      HistoryState(
        items: items ?? this.items,
        isLoading: isLoading ?? this.isLoading,
      );
}

class HistoryNotifier extends StateNotifier<HistoryState> {
  final HistoryService _service;

  HistoryNotifier(this._service) : super(const HistoryState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    final items = await _service.getHistory(limit: 500);
    state = state.copyWith(items: items, isLoading: false);
  }

  Future<void> delete(int id) async {
    await _service.deleteItem(id);
    await load();
  }

  Future<void> clearAll() async {
    await _service.clearAll();
    state = state.copyWith(items: []);
  }
}

final historyNotifierProvider =
    StateNotifierProvider<HistoryNotifier, HistoryState>((ref) {
  return HistoryNotifier(getIt<HistoryService>());
});
