import '../../database/database_helper.dart';

/// Data source for settings stored in SQLite
class SettingsDataSource {
  final DatabaseHelper _db;

  SettingsDataSource(this._db);

  Future<String?> get(String key) => _db.getSetting(key);

  Future<void> set(String key, String value) => _db.setSetting(key, value);

  Future<Map<String, String>> getAll(List<String> keys) async {
    final result = <String, String>{};
    for (final key in keys) {
      final value = await _db.getSetting(key);
      if (value != null) result[key] = value;
    }
    return result;
  }
}
