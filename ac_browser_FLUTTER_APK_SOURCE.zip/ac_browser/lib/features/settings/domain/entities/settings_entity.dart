import 'package:flutter/material.dart';

/// Domain entity for app settings
class SettingsEntity {
  final ThemeMode themeMode;
  final String searchEngine;
  final bool adBlockEnabled;
  final String homepageType;
  final double fontSize;
  final bool javascriptEnabled;
  final bool cookiesEnabled;
  final bool savePasswords;
  final bool safeBrowsing;

  const SettingsEntity({
    this.themeMode = ThemeMode.system,
    this.searchEngine = 'google',
    this.adBlockEnabled = true,
    this.homepageType = 'default',
    this.fontSize = 16.0,
    this.javascriptEnabled = true,
    this.cookiesEnabled = true,
    this.savePasswords = false,
    this.safeBrowsing = true,
  });

  SettingsEntity copyWith({
    ThemeMode? themeMode,
    String? searchEngine,
    bool? adBlockEnabled,
    String? homepageType,
    double? fontSize,
    bool? javascriptEnabled,
    bool? cookiesEnabled,
    bool? savePasswords,
    bool? safeBrowsing,
  }) {
    return SettingsEntity(
      themeMode: themeMode ?? this.themeMode,
      searchEngine: searchEngine ?? this.searchEngine,
      adBlockEnabled: adBlockEnabled ?? this.adBlockEnabled,
      homepageType: homepageType ?? this.homepageType,
      fontSize: fontSize ?? this.fontSize,
      javascriptEnabled: javascriptEnabled ?? this.javascriptEnabled,
      cookiesEnabled: cookiesEnabled ?? this.cookiesEnabled,
      savePasswords: savePasswords ?? this.savePasswords,
      safeBrowsing: safeBrowsing ?? this.safeBrowsing,
    );
  }
}
