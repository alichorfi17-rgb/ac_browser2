import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/settings_service.dart';

class SettingsNotifier extends StateNotifier<BrowserSettings> {
  final SettingsService _service;

  SettingsNotifier(this._service) : super(const BrowserSettings()) {
    _load();
  }

  Future<void> _load() async {
    final settings = await _service.loadSettings();
    state = settings;
  }

  Future<void> setTheme(ThemeMode mode) async {
    await _service.saveTheme(mode);
    state = state.copyWith(themeMode: mode);
  }

  Future<void> setSearchEngine(String engine) async {
    await _service.saveSearchEngine(engine);
    state = state.copyWith(searchEngine: engine);
  }

  Future<void> setAdBlockEnabled(bool enabled) async {
    await _service.saveAdBlockEnabled(enabled);
    state = state.copyWith(adBlockEnabled: enabled);
  }

  Future<void> setFontSize(double size) async {
    await _service.saveFontSize(size);
    state = state.copyWith(fontSize: size);
  }

  Future<void> setJavascriptEnabled(bool enabled) async {
    await _service.saveJavascriptEnabled(enabled);
    state = state.copyWith(javascriptEnabled: enabled);
  }

  Future<void> setCookiesEnabled(bool enabled) async {
    await _service.saveCookiesEnabled(enabled);
    state = state.copyWith(cookiesEnabled: enabled);
  }

  Future<void> setSafeBrowsing(bool enabled) async {
    await _service.saveSafeBrowsing(enabled);
    state = state.copyWith(safeBrowsing: enabled);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, BrowserSettings>((ref) {
  return SettingsNotifier(getIt<SettingsService>());
});
