import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/history_service.dart';
import '../../../../services/ad_block_service.dart';
import '../providers/settings_provider.dart';
import '../../../../core/constants/app_constants.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings',
            style: TextStyle(fontWeight: FontWeight.w600)),
      ),
      body: ListView(
        children: [
          // ─── General ───────────────────────────────────────────────────────
          _SectionHeader(title: 'General'),
          _SettingsTile(
            icon: Icons.search_rounded,
            iconColor: const Color(0xFF0A84FF),
            title: 'Search Engine',
            trailing: _SearchEngineDropdown(
              current: settings.searchEngine,
              onChanged: (v) => notifier.setSearchEngine(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.home_rounded,
            iconColor: Colors.orange,
            title: 'Homepage',
            subtitle: 'Default',
            onTap: () {},
          ),

          // ─── Privacy ───────────────────────────────────────────────────────
          _SectionHeader(title: 'Privacy'),
          _SettingsTile(
            icon: Icons.shield_rounded,
            iconColor: const Color(0xFF30D158),
            title: 'Ad Blocker',
            subtitle: settings.adBlockEnabled ? 'Enabled' : 'Disabled',
            trailing: Switch.adaptive(
              value: settings.adBlockEnabled,
              activeColor: const Color(0xFF0A84FF),
              onChanged: (v) => notifier.setAdBlockEnabled(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.lock_rounded,
            iconColor: const Color(0xFF30D158),
            title: 'Safe Browsing',
            subtitle: 'Warn about dangerous sites',
            trailing: Switch.adaptive(
              value: settings.safeBrowsing,
              activeColor: const Color(0xFF0A84FF),
              onChanged: (v) => notifier.setSafeBrowsing(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.cookie_outlined,
            iconColor: Colors.brown,
            title: 'Third-party Cookies',
            trailing: Switch.adaptive(
              value: settings.cookiesEnabled,
              activeColor: const Color(0xFF0A84FF),
              onChanged: (v) => notifier.setCookiesEnabled(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.history_rounded,
            iconColor: Colors.grey,
            title: 'Clear History',
            onTap: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  title: const Text('Clear History'),
                  content: const Text(
                      'This will delete all your browsing history.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel')),
                    FilledButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.red),
                      child: const Text('Clear'),
                    ),
                  ],
                ),
              );
              if (confirmed == true) {
                await getIt<HistoryService>().clearAll();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('History cleared'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
          ),
          _SettingsTile(
            icon: Icons.delete_sweep_rounded,
            iconColor: Colors.red,
            title: 'Clear Cache & Cookies',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Cache and cookies cleared'),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),

          // ─── Appearance ────────────────────────────────────────────────────
          _SectionHeader(title: 'Appearance'),
          _SettingsTile(
            icon: Icons.dark_mode_rounded,
            iconColor: Colors.indigo,
            title: 'Theme',
            trailing: _ThemeDropdown(
              current: settings.themeMode,
              onChanged: (v) => notifier.setTheme(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.text_fields_rounded,
            iconColor: Colors.teal,
            title: 'Font Size',
            subtitle: '${settings.fontSize.toInt()}px',
            onTap: () => _showFontSizeDialog(context, ref, settings.fontSize),
          ),

          // ─── Advanced ──────────────────────────────────────────────────────
          _SectionHeader(title: 'Advanced'),
          _SettingsTile(
            icon: Icons.code_rounded,
            iconColor: Colors.deepPurple,
            title: 'JavaScript',
            trailing: Switch.adaptive(
              value: settings.javascriptEnabled,
              activeColor: const Color(0xFF0A84FF),
              onChanged: (v) => notifier.setJavascriptEnabled(v),
            ),
          ),
          _SettingsTile(
            icon: Icons.refresh_rounded,
            iconColor: Colors.blue,
            title: 'Refresh Ad Block Rules',
            subtitle: 'Update blocking lists',
            onTap: () async {
              await getIt<AdBlockService>().refreshRules();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Ad block rules refreshed'),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),

          // ─── About ─────────────────────────────────────────────────────────
          _SectionHeader(title: 'About'),
          _SettingsTile(
            icon: Icons.info_outline_rounded,
            iconColor: const Color(0xFF0A84FF),
            title: 'AC Browser',
            subtitle:
                'Version ${AppConstants.appVersion} • By ${AppConstants.developer}',
            onTap: () => _showAbout(context),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _showFontSizeDialog(
      BuildContext context, WidgetRef ref, double current) {
    double value = current;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: const Text('Font Size'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('${value.toInt()}px',
                  style: const TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w700)),
              Slider(
                value: value,
                min: 12,
                max: 24,
                divisions: 12,
                label: '${value.toInt()}px',
                onChanged: (v) => setState(() => value = v),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                ref.read(settingsProvider.notifier).setFontSize(value);
                Navigator.pop(ctx);
              },
              child: const Text('Apply'),
            ),
          ],
        ),
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'AC Browser',
      applicationVersion: AppConstants.appVersion,
      applicationIcon: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0A84FF), Color(0xFF0066CC)],
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Center(
          child: Text('AC',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 22)),
        ),
      ),
      children: const [
        Text(
          'Fast, private and lightweight web browser with built-in ad blocking.',
        ),
      ],
    );
  }
}

// ─── Helpers ───────────────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Colors.grey[500],
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: iconColor.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor, size: 18),
      ),
      title: Text(title,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w400)),
      subtitle: subtitle != null
          ? Text(subtitle!,
              style:
                  const TextStyle(fontSize: 12, color: Colors.grey))
          : null,
      trailing: trailing ??
          (onTap != null
              ? const Icon(Icons.chevron_right_rounded,
                  color: Colors.grey, size: 20)
              : null),
      onTap: onTap,
    );
  }
}

class _SearchEngineDropdown extends StatelessWidget {
  final String current;
  final ValueChanged<String> onChanged;

  const _SearchEngineDropdown(
      {required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: current,
      underline: const SizedBox(),
      borderRadius: BorderRadius.circular(12),
      items: AppConstants.searchEngines.entries.map((e) {
        return DropdownMenuItem(
          value: e.key,
          child: Text(e.value.name,
              style: const TextStyle(fontSize: 14)),
        );
      }).toList(),
      onChanged: (v) => v != null ? onChanged(v) : null,
    );
  }
}

class _ThemeDropdown extends StatelessWidget {
  final ThemeMode current;
  final ValueChanged<ThemeMode> onChanged;

  const _ThemeDropdown({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButton<ThemeMode>(
      value: current,
      underline: const SizedBox(),
      borderRadius: BorderRadius.circular(12),
      items: const [
        DropdownMenuItem(
            value: ThemeMode.system,
            child: Text('System', style: TextStyle(fontSize: 14))),
        DropdownMenuItem(
            value: ThemeMode.light,
            child: Text('Light', style: TextStyle(fontSize: 14))),
        DropdownMenuItem(
            value: ThemeMode.dark,
            child: Text('Dark', style: TextStyle(fontSize: 14))),
      ],
      onChanged: (v) => v != null ? onChanged(v) : null,
    );
  }
}
