import 'package:dio/dio.dart';
import '../database/database_helper.dart';

/// Service for managing ad blocking rules and filtering requests
class AdBlockService {
  final DatabaseHelper _db;
  final Dio _dio;

  Set<String> _blockedDomains = {};
  List<RegExp> _blockedPatterns = [];
  bool _isInitialized = false;

  AdBlockService(this._db, this._dio);

  bool get isInitialized => _isInitialized;

  Future<void> initialize() async {
    try {
      final count = await _db.getAdBlockRulesCount();
      if (count == 0) {
        await _loadAndSaveRules();
      } else {
        await _loadFromDatabase();
      }
      _isInitialized = true;
    } catch (e) {
      // Use built-in minimal list on failure
      _loadBuiltInRules();
      _isInitialized = true;
    }
  }

  Future<void> _loadAndSaveRules() async {
    // Built-in essential rules for fast startup
    _loadBuiltInRules();

    // Try to load full lists in background
    _fetchAndUpdateRules();
  }

  void _loadBuiltInRules() {
    _blockedDomains = {
      'doubleclick.net',
      'googlesyndication.com',
      'googleadservices.com',
      'google-analytics.com',
      'facebook.net',
      'connect.facebook.net',
      'analytics.twitter.com',
      'platform.twitter.com',
      'ads.twitter.com',
      'amazon-adsystem.com',
      'adsystem.amazon.com',
      'advertising.com',
      'adnxs.com',
      'adsafeprotected.com',
      'moatads.com',
      'outbrain.com',
      'taboola.com',
      'criteo.com',
      'criteo.net',
      'rubiconproject.com',
      'pubmatic.com',
      'openx.net',
      'smartadserver.com',
      'mopub.com',
      'applovin.com',
      'inmobi.com',
      'unity3d.com',
      'unityads.unity3d.com',
      'chartboost.com',
      'vungle.com',
      'adcolony.com',
      'appnexus.com',
      'lijit.com',
      'sovrn.com',
      'triplelift.com',
      'sharethrough.com',
      '33across.com',
      'yieldmo.com',
      'spotxchange.com',
      'springserve.com',
      'teads.tv',
      'revcontent.com',
      'mgid.com',
      'zergnet.com',
      'mediavine.com',
      'mediaalpha.com',
      'adsrvr.org',
      'eyeota.net',
      'bluekai.com',
      'krxd.net',
      'crwdcntrl.net',
      'demdex.net',
      'scorecardresearch.com',
      'quantserve.com',
      'comscore.com',
      'hotjar.com',
      'mouseflow.com',
      'fullstory.com',
      'logrocket.com',
      'mixpanel.com',
      'amplitude.com',
      'segment.com',
      'intercom.io',
      'drift.com',
      'hubspot.com',
      'marketo.com',
      'pardot.com',
    };

    _blockedPatterns = [
      RegExp(r'\/ads?\/', caseSensitive: false),
      RegExp(r'\/advert', caseSensitive: false),
      RegExp(r'\/banner', caseSensitive: false),
      RegExp(r'\/tracking', caseSensitive: false),
      RegExp(r'\/telemetry', caseSensitive: false),
      RegExp(r'\/pixel\.', caseSensitive: false),
      RegExp(r'\/beacon\.', caseSensitive: false),
      RegExp(r'\/analytics', caseSensitive: false),
    ];
  }

  Future<void> _loadFromDatabase() async {
    try {
      final patterns = await _db.getAdBlockPatterns();
      _blockedDomains = Set.from(patterns.where((p) => !p.contains('/')));
      _blockedPatterns = patterns
          .where((p) => p.contains('/') || p.contains('*'))
          .map((p) => _convertToRegExp(p))
          .whereType<RegExp>()
          .toList();
    } catch (e) {
      _loadBuiltInRules();
    }
  }

  Future<void> _fetchAndUpdateRules() async {
    const lists = [
      'https://easylist.to/easylist/easylist.txt',
      'https://easylist.to/easylist/easyprivacy.txt',
    ];

    for (final url in lists) {
      try {
        final response = await _dio.get<String>(url);
        if (response.statusCode == 200 && response.data != null) {
          final rules = _parseAdBlockList(response.data!, url);
          await _db.insertAdBlockRules(rules);
        }
      } catch (e) {
        // Silently continue with built-in rules
      }
    }
  }

  List<Map<String, dynamic>> _parseAdBlockList(String content, String listName) {
    final rules = <Map<String, dynamic>>[];
    final lines = content.split('\n');

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty || trimmed.startsWith('!') || trimmed.startsWith('[')) {
        continue;
      }

      // Skip cosmetic rules (##) and exceptions (@@)
      if (trimmed.contains('##') || trimmed.startsWith('@@')) continue;

      rules.add({
        'pattern': trimmed,
        'list_name': listName,
        'rule_type': 'block',
      });
    }

    return rules;
  }

  RegExp? _convertToRegExp(String pattern) {
    try {
      var regexStr = pattern
          .replaceAll('.', r'\.')
          .replaceAll('*', '.*')
          .replaceAll('?', '.');
      return RegExp(regexStr, caseSensitive: false);
    } catch (e) {
      return null;
    }
  }

  /// Returns true if the given URL should be blocked
  bool shouldBlock(String url) {
    try {
      final uri = Uri.parse(url);
      final host = uri.host.toLowerCase();

      // Check domain blocklist
      if (_blockedDomains.contains(host)) return true;

      // Check subdomain matching
      for (final domain in _blockedDomains) {
        if (host.endsWith('.$domain')) return true;
      }

      // Check URL patterns
      for (final pattern in _blockedPatterns) {
        if (pattern.hasMatch(url)) return true;
      }

      return false;
    } catch (e) {
      return false;
    }
  }

  /// Get count of blocked domains in ruleset
  int get blockedDomainsCount => _blockedDomains.length;

  /// Refresh rules from network
  Future<void> refreshRules() async {
    await _db.clearAdBlockRules();
    _loadBuiltInRules();
    await _fetchAndUpdateRules();
  }
}
