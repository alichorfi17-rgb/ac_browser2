import 'package:package_info_plus/package_info_plus.dart';

class AppInfoService {
  AppInfoService._();
  static final instance = AppInfoService._();

  PackageInfo? _info;

  Future<void> initialize() async {
    _info = await PackageInfo.fromPlatform();
  }

  String get appName => _info?.appName ?? 'AC Browser';
  String get version => _info?.version ?? '1.0.0';
  String get buildNumber => _info?.buildNumber ?? '1';
  String get packageName => _info?.packageName ?? 'com.ac.acbrowser';
  String get fullVersion => '$version+$buildNumber';
}
