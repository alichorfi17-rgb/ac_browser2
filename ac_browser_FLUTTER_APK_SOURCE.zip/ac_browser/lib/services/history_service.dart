import '../database/database_helper.dart';

class HistoryItem {
  final int? id;
  final String? title;
  final String url;
  final DateTime visitTime;

  HistoryItem({
    this.id,
    this.title,
    required this.url,
    DateTime? visitTime,
  }) : visitTime = visitTime ?? DateTime.now();

  factory HistoryItem.fromMap(Map<String, dynamic> map) {
    return HistoryItem(
      id: map['id'] as int?,
      title: map['title'] as String?,
      url: map['url'] as String,
      visitTime: DateTime.tryParse(map['visit_time'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        if (title != null) 'title': title,
        'url': url,
        'visit_time': visitTime.toIso8601String(),
      };
}

class HistoryService {
  final DatabaseHelper _db;

  HistoryService(this._db);

  Future<void> addEntry({
    required String url,
    String? title,
    bool isPrivate = false,
  }) async {
    if (isPrivate) return; // Don't save private browsing history
    if (url == 'about:blank' || url.isEmpty) return;

    await _db.insertHistory({
      'title': title ?? url,
      'url': url,
      'visit_time': DateTime.now().toIso8601String(),
    });
  }

  Future<List<HistoryItem>> getHistory({int limit = 100}) async {
    final maps = await _db.getHistory(limit: limit);
    return maps.map((m) => HistoryItem.fromMap(m)).toList();
  }

  Future<List<HistoryItem>> searchHistory(String query) async {
    final maps = await _db.searchHistory(query);
    return maps.map((m) => HistoryItem.fromMap(m)).toList();
  }

  Future<void> deleteItem(int id) => _db.deleteHistoryItem(id);

  Future<void> clearAll() => _db.clearAllHistory();
}
