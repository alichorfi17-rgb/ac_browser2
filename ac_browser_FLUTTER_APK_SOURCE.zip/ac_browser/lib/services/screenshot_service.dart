import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ScreenshotService {
  ScreenshotService._();
  static final instance = ScreenshotService._();

  Future<String?> captureFullPage(
      InAppWebViewController controller) async {
    try {
      final screenshot = await controller.takeScreenshot(
        screenshotConfiguration: ScreenshotConfiguration(
          compressFormat: CompressFormat.PNG,
          quality: 100,
        ),
      );
      if (screenshot == null) return null;
      return await _saveToFile(screenshot, 'fullpage');
    } catch (e) {
      return null;
    }
  }

  Future<String?> captureVisible(
      InAppWebViewController controller) async {
    try {
      final screenshot = await controller.takeScreenshot(
        screenshotConfiguration: ScreenshotConfiguration(
          compressFormat: CompressFormat.PNG,
          quality: 95,
        ),
      );
      if (screenshot == null) return null;
      return await _saveToFile(screenshot, 'screenshot');
    } catch (e) {
      return null;
    }
  }

  Future<String?> _saveToFile(Uint8List bytes, String prefix) async {
    final dir = await getExternalStorageDirectory() ??
        await getApplicationDocumentsDirectory();
    final screenshotsDir =
        Directory('${dir.path}/ACBrowser/Screenshots');
    await screenshotsDir.create(recursive: true);
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final file =
        File('${screenshotsDir.path}/${prefix}_$timestamp.png');
    await file.writeAsBytes(bytes);
    return file.path;
  }

  Future<void> shareScreenshot(String filePath) async {
    await Share.shareXFiles(
      [XFile(filePath)],
      text: 'Screenshot taken with AC Browser',
    );
  }

  void showScreenshotOptions(
      BuildContext context, InAppWebViewController controller) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text(
              'Screenshot',
              style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.screenshot_rounded,
                  color: Color(0xFF0A84FF)),
              title: const Text('Capture Visible Area'),
              onTap: () async {
                Navigator.pop(ctx);
                final path = await captureVisible(controller);
                if (path != null && context.mounted) {
                  _showSavedSnackbar(context, path);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.screenshot_monitor_rounded,
                  color: Color(0xFF0A84FF)),
              title: const Text('Capture Full Page'),
              onTap: () async {
                Navigator.pop(ctx);
                final path = await captureFullPage(controller);
                if (path != null && context.mounted) {
                  _showSavedSnackbar(context, path);
                }
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showSavedSnackbar(BuildContext context, String path) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Screenshot saved'),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        action: SnackBarAction(
          label: 'Share',
          onPressed: () => shareScreenshot(path),
        ),
      ),
    );
  }
}
