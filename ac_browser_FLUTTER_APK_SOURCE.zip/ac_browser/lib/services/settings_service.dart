import 'package:flutter/material.dart';
import '../database/database_helper.dart';

class BrowserSettings {
  final ThemeMode themeMode;
  final String searchEngine;
  final bool adBlockEnabled;
  final String homepageType;
  final bool isPrivateMode;
  final double fontSize;
  final bool javascriptEnabled;
  final bool cookiesEnabled;
  final bool savePasswords;
  final bool safeBrowsing;

  const BrowserSettings({
    this.themeMode = ThemeMode.system,
    this.searchEngine = 'google',
    this.adBlockEnabled = true,
    this.homepageType = 'default',
    this.isPrivateMode = false,
    this.fontSize = 16.0,
    this.javascriptEnabled = true,
    this.cookiesEnabled = true,
    this.savePasswords = false,
    this.safeBrowsing = true,
  });

  BrowserSettings copyWith({
    ThemeMode? themeMode,
    String? searchEngine,
    bool? adBlockEnabled,
    String? homepageType,
    bool? isPrivateMode,
    double? fontSize,
    bool? javascriptEnabled,
    bool? cookiesEnabled,
    bool? savePasswords,
    bool? safeBrowsing,
  }) {
    return BrowserSettings(
      themeMode: themeMode ?? this.themeMode,
      searchEngine: searchEngine ?? this.searchEngine,
      adBlockEnabled: adBlockEnabled ?? this.adBlockEnabled,
      homepageType: homepageType ?? this.homepageType,
      isPrivateMode: isPrivateMode ?? this.isPrivateMode,
      fontSize: fontSize ?? this.fontSize,
      javascriptEnabled: javascriptEnabled ?? this.javascriptEnabled,
      cookiesEnabled: cookiesEnabled ?? this.cookiesEnabled,
      savePasswords: savePasswords ?? this.savePasswords,
      safeBrowsing: safeBrowsing ?? this.safeBrowsing,
    );
  }
}

class SettingsService {
  final DatabaseHelper _db;

  SettingsService(this._db);

  Future<BrowserSettings> loadSettings() async {
    final theme = await _db.getSetting('theme') ?? 'system';
    final searchEngine = await _db.getSetting('search_engine') ?? 'google';
    final adBlock = await _db.getSetting('adblock_enabled') ?? 'true';
    final homepage = await _db.getSetting('homepage_type') ?? 'default';
    final fontSize = await _db.getSetting('font_size') ?? '16';
    final javascript = await _db.getSetting('javascript_enabled') ?? 'true';
    final cookies = await _db.getSetting('cookies_enabled') ?? 'true';
    final savePass = await _db.getSetting('save_passwords') ?? 'false';
    final safeBrowse = await _db.getSetting('safe_browsing') ?? 'true';

    return BrowserSettings(
      themeMode: _parseThemeMode(theme),
      searchEngine: searchEngine,
      adBlockEnabled: adBlock == 'true',
      homepageType: homepage,
      fontSize: double.tryParse(fontSize) ?? 16.0,
      javascriptEnabled: javascript == 'true',
      cookiesEnabled: cookies == 'true',
      savePasswords: savePass == 'true',
      safeBrowsing: safeBrowse == 'true',
    );
  }

  Future<void> saveTheme(ThemeMode mode) async {
    await _db.setSetting('theme', _themeModeToString(mode));
  }

  Future<void> saveSearchEngine(String engine) async {
    await _db.setSetting('search_engine', engine);
  }

  Future<void> saveAdBlockEnabled(bool enabled) async {
    await _db.setSetting('adblock_enabled', enabled.toString());
  }

  Future<void> saveFontSize(double size) async {
    await _db.setSetting('font_size', size.toString());
  }

  Future<void> saveJavascriptEnabled(bool enabled) async {
    await _db.setSetting('javascript_enabled', enabled.toString());
  }

  Future<void> saveCookiesEnabled(bool enabled) async {
    await _db.setSetting('cookies_enabled', enabled.toString());
  }

  Future<void> saveSafeBrowsing(bool enabled) async {
    await _db.setSetting('safe_browsing', enabled.toString());
  }

  ThemeMode _parseThemeMode(String value) {
    switch (value) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  String _themeModeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      default:
        return 'system';
    }
  }
}
